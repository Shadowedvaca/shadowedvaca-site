================================================================================
MEANDERING MUCK - PRESS KIT
================================================================================

Thank you for your interest in Meandering Muck!

This press kit contains all the assets you need to write about or create 
content featuring our game.

CONTENTS:
- Screenshots/ - High-resolution gameplay screenshots
- Logos/ - Game and company logos in multiple formats
- FACT_SHEET.txt - All game information in copy-paste format
- README.txt - This file

USAGE GUIDELINES:
- You're free to use these assets for editorial coverage, reviews, previews,
  and promotional content
- Please credit "Shadowedvaca LLC" when using assets
- For custom assets or specific requests, contact: contact@shadowedvaca.com

REVIEW CODES:
To request a TestFlight (iOS) or Play Store beta (Android) review code, 
please email contact@shadowedvaca.com with:
- Your name and outlet/channel
- Platform preference (iOS or Android)
- Link to previous work
- Estimated coverage date (if applicable)

QUESTIONS?
For any questions, additional assets, or interview requests:
Email: contact@shadowedvaca.com
Website: https://shadowedvaca.com

Thank you for helping share Meandering Muck with the world!

- The Shadowedvaca Team

================================================================================